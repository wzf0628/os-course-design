if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    todoList?: TodoItem[];
}
import PreferencesUtil from "@normalized:N&&&entry/src/main/ets/utils/PerferencesUtil&";
import router from "@ohos:router";
import type { TodoItem } from '../model/ToDoItem';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__todoList = new ObservedPropertyObjectPU([], this, "todoList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.todoList !== undefined) {
            this.todoList = params.todoList;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__todoList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__todoList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __todoList: ObservedPropertyObjectPU<TodoItem[]>;
    get todoList() {
        return this.__todoList.get();
    }
    set todoList(newValue: TodoItem[]) {
        this.__todoList.set(newValue);
    }
    async aboutToAppear(): Promise<void> {
        await this.loadData();
    }
    async onPageShow(): Promise<void> {
        await this.loadData();
    }
    async loadData(): Promise<void> {
        const data = await PreferencesUtil.getTodoList();
        this.todoList = data;
    }
    async deleteTodo(id: number): Promise<void> {
        this.todoList = this.todoList.filter((item: TodoItem) => item.id !== id);
        await PreferencesUtil.saveTodoList(this.todoList);
    }
    async toggleComplete(id: number): Promise<void> {
        this.todoList = this.todoList.map((item: TodoItem) => {
            if (item.id === id) {
                return {
                    id: item.id,
                    content: item.content,
                    completed: !item.completed
                };
            }
            return item;
        });
        await PreferencesUtil.saveTodoList(this.todoList);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(41:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#ffffff');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("待办备忘录");
            Text.debugLine("entry/src/main/ets/pages/Index.ets(42:7)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.margin(25);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("+ 新增任务");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(47:7)", "entry");
            Button.width('90%');
            Button.backgroundColor('#0088ff');
            Button.onClick(() => {
                router.pushUrl({ url: 'pages/AddToDo' })
                    .catch(() => {
                    console.error('页面跳转失败：');
                });
                ;
            });
            Button.margin({ bottom: 15 });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 20 });
            List.debugLine("entry/src/main/ets/pages/Index.ets(58:7)", "entry");
            List.width('100%');
            List.padding(10);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, true);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/Index.ets(60:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/Index.ets(61:13)", "entry");
                            Row.width('100%');
                            Row.backgroundColor('#f5f5f5');
                            Row.borderRadius(8);
                            Row.padding(5);
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Checkbox.create();
                            Checkbox.debugLine("entry/src/main/ets/pages/Index.ets(62:15)", "entry");
                            Checkbox.select(item.completed);
                            Checkbox.onChange(() => this.toggleComplete(item.id));
                            Checkbox.margin(10);
                        }, Checkbox);
                        Checkbox.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.content);
                            Text.debugLine("entry/src/main/ets/pages/Index.ets(67:15)", "entry");
                            Text.fontSize(18);
                            Text.decoration({ type: item.completed ? TextDecorationType.LineThrough : TextDecorationType.None });
                            Text.flexGrow(1);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel("编辑");
                            Button.debugLine("entry/src/main/ets/pages/Index.ets(72:15)", "entry");
                            Button.width(50);
                            Button.backgroundColor('#555555');
                            Button.onClick(() => {
                                router.pushUrl({
                                    url: 'pages/EditToDo',
                                    params: { id: item.id, content: item.content }
                                });
                            });
                        }, Button);
                        Button.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel("删除");
                            Button.debugLine("entry/src/main/ets/pages/Index.ets(82:15)", "entry");
                            Button.width(50);
                            Button.backgroundColor('#ff4444');
                            Button.onClick(() => this.deleteTodo(item.id));
                            Button.margin({ left: 10 });
                        }, Button);
                        Button.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.todoList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
export default Index;
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
