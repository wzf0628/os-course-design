import dataPreferences from "@ohos:data.preferences";
import type { TodoItem } from '../model/ToDoItem';
import type { Context } from "@ohos:arkui.UIContext";
class PreferencesUtil {
    private readonly PREFERENCES_NAME: string = 'todo_db';
    private readonly TODO_KEY: string = 'todo_list';
    private context: Context = getContext(this);
    async getTodoList(): Promise<TodoItem[]> {
        // 修复：传入 this.context 上下文
        const pref = await dataPreferences.getPreferences(this.context, this.PREFERENCES_NAME);
        const data = await pref.get(this.TODO_KEY, '[]') as string;
        return JSON.parse(data) as TodoItem[];
    }
    async saveTodoList(list: TodoItem[]): Promise<void> {
        const pref = await dataPreferences.getPreferences(this.context, this.PREFERENCES_NAME);
        await pref.put(this.TODO_KEY, JSON.stringify(list));
        await pref.flush();
    }
}
export default new PreferencesUtil();
