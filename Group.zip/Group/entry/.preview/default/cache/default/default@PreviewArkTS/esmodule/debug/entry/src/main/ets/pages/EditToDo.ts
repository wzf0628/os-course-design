if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface EditTodo_Params {
    content?: string;
    itemId?: number;
}
import PreferencesUtil from "@normalized:N&&&entry/src/main/ets/utils/PerferencesUtil&";
import router from "@ohos:router";
import type { TodoItem } from '../model/ToDoItem';
interface EditParams {
    id: number;
    content: string;
}
class EditTodo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__content = new ObservedPropertySimplePU('', this, "content");
        this.itemId = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: EditTodo_Params) {
        if (params.content !== undefined) {
            this.content = params.content;
        }
        if (params.itemId !== undefined) {
            this.itemId = params.itemId;
        }
    }
    updateStateVars(params: EditTodo_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__content.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__content.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __content: ObservedPropertySimplePU<string>;
    get content() {
        return this.__content.get();
    }
    set content(newValue: string) {
        this.__content.set(newValue);
    }
    private itemId: number;
    aboutToAppear(): void {
        const params = router.getParams() as EditParams;
        this.itemId = params.id;
        this.content = params.content;
    }
    async saveEdit(): Promise<void> {
        const list: TodoItem[] = await PreferencesUtil.getTodoList();
        const newList = list.map((item: TodoItem) => {
            if (item.id === this.itemId) {
                return {
                    id: item.id,
                    content: this.content,
                    completed: item.completed
                };
            }
            return item;
        });
        await PreferencesUtil.saveTodoList(newList);
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditToDo.ets(40:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#fff');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("编辑任务");
            Text.debugLine("entry/src/main/ets/pages/EditToDo.ets(41:7)", "entry");
            Text.fontSize(26);
            Text.margin(20);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.content });
            TextInput.debugLine("entry/src/main/ets/pages/EditToDo.ets(45:7)", "entry");
            TextInput.width('90%');
            TextInput.height(40);
            TextInput.border({ width: 1 });
            TextInput.margin(10);
            TextInput.onChange((v: string) => this.content = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/EditToDo.ets(52:7)", "entry");
            Row.margin(20);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("取消");
            Button.debugLine("entry/src/main/ets/pages/EditToDo.ets(53:9)", "entry");
            Button.onClick(() => router.back());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("保存");
            Button.debugLine("entry/src/main/ets/pages/EditToDo.ets(54:9)", "entry");
            Button.backgroundColor('#0088ff');
            Button.onClick(() => this.saveEdit());
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "EditTodo";
    }
}
export default EditTodo;
registerNamedRoute(() => new EditTodo(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/EditToDo", pageFullPath: "entry/src/main/ets/pages/EditToDo", integratedHsp: "false", moduleType: "followWithHap" });
