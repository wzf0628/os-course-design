if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AddTodo_Params {
    content?: string;
}
import PreferencesUtil from "@normalized:N&&&entry/src/main/ets/utils/PerferencesUtil&";
import router from "@ohos:router";
import type { TodoItem } from '../model/ToDoItem';
class AddTodo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__content = new ObservedPropertySimplePU('', this, "content");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AddTodo_Params) {
        if (params.content !== undefined) {
            this.content = params.content;
        }
    }
    updateStateVars(params: AddTodo_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__content.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__content.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __content: ObservedPropertySimplePU<string>;
    get content() {
        return this.__content.get();
    }
    set content(newValue: string) {
        this.__content.set(newValue);
    }
    async addTodo(): Promise<void> {
        if (!this.content.trim())
            return;
        const list: TodoItem[] = await PreferencesUtil.getTodoList();
        const newItem: TodoItem = {
            id: Date.now(),
            content: this.content,
            completed: false
        };
        list.push(newItem);
        await PreferencesUtil.saveTodoList(list);
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddToDo.ets(27:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#fff');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("新增任务");
            Text.debugLine("entry/src/main/ets/pages/AddToDo.ets(28:7)", "entry");
            Text.fontSize(26);
            Text.margin(20);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "请输入任务内容" });
            TextInput.debugLine("entry/src/main/ets/pages/AddToDo.ets(32:7)", "entry");
            TextInput.width('90%');
            TextInput.height(40);
            TextInput.border({ width: 1 });
            TextInput.margin(10);
            TextInput.onChange((v: string) => this.content = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/AddToDo.ets(39:7)", "entry");
            Row.margin(20);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("取消");
            Button.debugLine("entry/src/main/ets/pages/AddToDo.ets(40:9)", "entry");
            Button.onClick(() => router.back());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("保存");
            Button.debugLine("entry/src/main/ets/pages/AddToDo.ets(41:9)", "entry");
            Button.backgroundColor('#0088ff');
            Button.onClick(() => this.addTodo());
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "AddTodo";
    }
}
export default AddTodo;
registerNamedRoute(() => new AddTodo(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/AddToDo", pageFullPath: "entry/src/main/ets/pages/AddToDo", integratedHsp: "false", moduleType: "followWithHap" });
